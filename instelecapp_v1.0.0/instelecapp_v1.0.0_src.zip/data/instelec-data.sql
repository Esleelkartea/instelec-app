\copy PROVINCIAS FROM 'provincias.txt' WITH DELIMITER ';'
\copy LOCALIDADES FROM 'localidadesSort.txt' WITH DELIMITER ';'